#ifndef I2C_H_
#define I2C_H_

#include <stdint.h>

void i2c_init(void);

void i2c_set_normal_mode(void);

void i2c_set_calib(void);

void i2c_trigger_measurement(void);

void i2c_get_reading(uint8_t *buffer);

#endif /* I2C_H_ */
