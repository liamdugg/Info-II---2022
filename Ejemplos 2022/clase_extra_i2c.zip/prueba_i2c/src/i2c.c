#include <i2c.h>

#include <swm.h>

#define		SYSCON_SYSAHBCLKCTRL0		(*((volatile uint32_t *)(0x40048080)))

#define		SYSCON_PRESETCTRL0			(*((volatile uint32_t *)(0x40048088)))

#define		SYSCON_I2C0CLKSEL			(*((volatile uint32_t *)(0x400480A4)))

#define		I2C0_CFG					(*((volatile uint32_t *)(0x40050000)))
#define		I2C0_STAT					(*((volatile uint32_t *)(0x40050004)))
#define		I2C0_CLKDIV					(*((volatile uint32_t *)(0x40050014)))
#define		I2C0_MSTCTL					(*((volatile uint32_t *)(0x40050020)))
#define		I2C0_MSTTIME				(*((volatile uint32_t *)(0x40050024)))
#define		I2C0_MSTDATA				(*((volatile uint32_t *)(0x40050028)))

void i2c_init(void) {
	// Limpiamos reset del periferico
	SYSCON_PRESETCTRL0 &= ~(1 << 5);
	SYSCON_PRESETCTRL0 |= (1 << 5);

	// Seleccionamos FRO como fuente de clock del periferico
	SYSCON_I2C0CLKSEL = 0;

	// Habilitamos clock para el perfierico a nivel SYSCON
	SYSCON_SYSAHBCLKCTRL0 |= (1 << 5);

	// Configuramos pines en la SWM
	swm_power_on();
	swm_enable_i2c0_scl();
	swm_enable_i2c0_sda();

	// Configuramos clkdiv del periferico en /12
	I2C0_CLKDIV = 11;

	// Configuramos tiempo alto y bajo de SCL en 3
	I2C0_MSTTIME = 0x03 | (0x03 << 4);

	// Configuramos el periferico como modo master
	I2C0_CFG |= (1 << 0);
}

void i2c_set_normal_mode(void) {
	// Escribimos primero la direccion + R/W
	// Desplazamos la direccion porque es de 7 bits
	// Y escribimos 0 en el bit menos significativo para
	// indicar escritura
	I2C0_MSTDATA = (0x38 << 1) | 0x00;

	// Escribimos registro de control para iniciar la transmision
	// el periferico en este punto pasa a mandar el start + addr + r/w
	I2C0_MSTCTL = (1 << 1);

	// NOTA: NO HACER EN EL PARCIAL!!!!!!!!!
	while (!(I2C0_STAT & (1 << 0))) {}

	// Escribimos en data el dato a mandar
	I2C0_MSTDATA = 0xA8;

	// Forzamos a que el periferico envie el dato en MSTDATA
	I2C0_MSTCTL = (1 << 0);

	// NOTA: NO HACER EN EL PARCIAL!!!!!!!!!
	while (!(I2C0_STAT & (1 << 0))) {}

	// Escribimos en data el dato a mandar
	I2C0_MSTDATA = 0x00;

	// Forzamos a que el periferico siga leyendo y lo guarde el MSTDATA
	I2C0_MSTCTL = (1 << 0);

	// NOTA: NO HACER EN EL PARCIAL!!!!!!!!!
	while (!(I2C0_STAT & (1 << 0))) {}

	// Escribimos en data el dato a mandar
	I2C0_MSTDATA = 0x00;

	// Forzamos a que el periferico siga leyendo y lo guarde el MSTDATA
	I2C0_MSTCTL = (1 << 0);

	// NOTA: NO HACER EN EL PARCIAL!!!!!!!!!
	while (!(I2C0_STAT & (1 << 0))) {}

	// Enviamos STOP
	I2C0_MSTCTL = (1 << 2);
}

void i2c_set_calib(void) {
	// Escribimos primero la direccion + R/W
	// Desplazamos la direccion porque es de 7 bits
	// Y escribimos 0 en el bit menos significativo para
	// indicar escritura
	I2C0_MSTDATA = (0x38 << 1) | 0x00;

	// Escribimos registro de control para iniciar la transmision
	// el periferico en este punto pasa a mandar el start + addr + r/w
	I2C0_MSTCTL = (1 << 1);

	// NOTA: NO HACER EN EL PARCIAL!!!!!!!!!
	while (!(I2C0_STAT & (1 << 0))) {}

	// Escribimos en data el dato a mandar
	I2C0_MSTDATA = 0xE1;

	// Forzamos a que el periferico envie el dato en MSTDATA
	I2C0_MSTCTL = (1 << 0);

	// NOTA: NO HACER EN EL PARCIAL!!!!!!!!!
	while (!(I2C0_STAT & (1 << 0))) {}

	// Escribimos en data el dato a mandar
	I2C0_MSTDATA = 0x08;

	// Forzamos a que el periferico siga leyendo y lo guarde el MSTDATA
	I2C0_MSTCTL = (1 << 0);

	// NOTA: NO HACER EN EL PARCIAL!!!!!!!!!
	while (!(I2C0_STAT & (1 << 0))) {}

	// Escribimos en data el dato a mandar
	I2C0_MSTDATA = 0x00;

	// Forzamos a que el periferico siga leyendo y lo guarde el MSTDATA
	I2C0_MSTCTL = (1 << 0);

	// NOTA: NO HACER EN EL PARCIAL!!!!!!!!!
	while (!(I2C0_STAT & (1 << 0))) {}

	// Enviamos STOP
	I2C0_MSTCTL = (1 << 2);
}

void i2c_trigger_measurement(void) {
	// Escribimos primero la direccion + R/W
	// Desplazamos la direccion porque es de 7 bits
	// Y escribimos 0 en el bit menos significativo para
	// indicar escritura
	I2C0_MSTDATA = (0x38 << 1) | 0x00;

	// Escribimos registro de control para iniciar la transmision
	// el periferico en este punto pasa a mandar el start + addr + r/w
	I2C0_MSTCTL = (1 << 1);

	// NOTA: NO HACER EN EL PARCIAL!!!!!!!!!
	while (!(I2C0_STAT & (1 << 0))) {}

	// Escribimos en data el dato a mandar
	I2C0_MSTDATA = 0xAC;

	// Forzamos a que el periferico envie el dato en MSTDATA
	I2C0_MSTCTL = (1 << 0);

	// NOTA: NO HACER EN EL PARCIAL!!!!!!!!!
	while (!(I2C0_STAT & (1 << 0))) {}

	// Escribimos en data el dato a mandar
	I2C0_MSTDATA = 0x33;

	// Forzamos a que el periferico siga leyendo y lo guarde el MSTDATA
	I2C0_MSTCTL = (1 << 0);

	// NOTA: NO HACER EN EL PARCIAL!!!!!!!!!
	while (!(I2C0_STAT & (1 << 0))) {}

	// Escribimos en data el dato a mandar
	I2C0_MSTDATA = 0x00;

	// Forzamos a que el periferico siga leyendo y lo guarde el MSTDATA
	I2C0_MSTCTL = (1 << 0);

	// NOTA: NO HACER EN EL PARCIAL!!!!!!!!!
	while (!(I2C0_STAT & (1 << 0))) {}

	// Enviamos STOP
	I2C0_MSTCTL = (1 << 2);
}

void i2c_get_reading(uint8_t *buffer) {
	// Escribimos primero la direccion + R/W
	// Desplazamos la direccion porque es de 7 bits
	// Y escribimos 1 en el bit menos significativo para
	// indicar lectura
	I2C0_MSTDATA = (0x38 << 1) | 0x01;

	// Escribimos registro de control para iniciar la transmision
	// el periferico en este punto pasa a mandar el start + addr + r/w
	I2C0_MSTCTL = (1 << 1);

	// NOTA: NO HACER EN EL PARCIAL!!!!!!!!!
	while (!(I2C0_STAT & (1 << 0))) {}

	// Leemos el buffer de I2C con el dato recibido
	buffer[0] = I2C0_MSTDATA;

	// Leemos los multiples datos
	for (uint32_t idx = 0; idx < 5; idx++) {
		// Escribimos en continue para leer mas datos
		I2C0_MSTCTL = (1 << 0);

		// NOTA: NO HACER EN EL PARCIAL!!!!!!!!!
		while (!(I2C0_STAT & (1 << 0))) {}

		// Leemos el buffer de I2C con el dato recibido
		buffer[idx + 1] = I2C0_MSTDATA;
	}

	// Enviamos STOP
	I2C0_MSTCTL = (1 << 2);
}
