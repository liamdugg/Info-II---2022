#include <cr_section_macros.h>

#include <stdio.h>

#include <i2c.h>
#include <systick.h>

int main(void) {
	uint64_t actual;

	systick_init();
	i2c_init();

	actual = systick_tick_time();

	while ((actual + 500) > systick_tick_time()) {}

	i2c_set_normal_mode();
	actual = systick_tick_time();

	while ((actual + 500) > systick_tick_time()) {}

	i2c_set_calib();
	actual = systick_tick_time();

	while ((actual + 500) > systick_tick_time()) {}

	i2c_trigger_measurement();
	actual = systick_tick_time();

	while ((actual + 500) > systick_tick_time()) {}

	uint8_t buffer[10];

	for (int i = 0; i < 10; i++) {
		buffer[i] = 0;
	}

	i2c_get_reading(buffer);

	while (1) {

	}

	return 0;
}
